"use client";

import { useAuth } from "@/context/auth-context";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

export default function MiEquipoPage() {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.push("/login");
    }
  }, [user, loading, router]);

  if (loading) return <p>Cargando...</p>;

  if (!user) return null;

  return (
    <div>
      <h1>Bienvenido al equipo, {user.displayName}!</h1>
      <p>Correo electrónico: {user.email}</p>
    </div>
  );
}
