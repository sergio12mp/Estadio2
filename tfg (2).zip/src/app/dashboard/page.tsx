"use client";

import { useAuth } from "@/context/auth-context";

export default function HomePage() {
  const { user, loading } = useAuth();

  if (loading) return <p>Cargando...</p>;

  if (!user) return <p>Debes iniciar sesión</p>;

  return (
    <div>
      <h1>Bienvenido {user.displayName}</h1>
      <p>Tu email es: {user.email}</p>
    </div>
  );
}
