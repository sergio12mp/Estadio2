"use client";

import { useAuth } from "@/context/auth-context";
import { useEffect, useState } from "react";
import { GetManagerByEmail, CreateManager } from "@/database/manager";
import NavBar from "./navbar";
import { NavbarLite } from "./navbarLite";

export function SelectNavbar() {
  const { user } = useAuth();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const syncManager = async () => {
      if (!user?.email || !user.displayName || !user.uid) {
        setReady(true);
        return;
      }

      const existing = await GetManagerByEmail(user.email);

      if (!existing) {
        await CreateManager({
          name: user.displayName,
          email: user.email,
          idGoogle: user.uid,
        });
      }

      setReady(true);
    };

    syncManager();
  }, [user]);

  if (!ready) return <p>Cargando...</p>;

  return user ? <NavBar /> : <NavbarLite />;
}
