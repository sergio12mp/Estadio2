// src/database/manager.ts
import { db } from "@/lib/mysql";

// Buscar manager por email
export async function GetManagerByEmail(email: string) {
  const [rows]: [any[]] = await db.query("SELECT * FROM Manager WHERE email = ?", [email]);
  return (rows as any[])[0] || null;
}

// Crear nuevo manager
export async function CreateManager({
  name,
  email,
  idGoogle,
}: {
  name: string;
  email: string;
  idGoogle: string;
}) {
  const [result]: [{ insertId: number }] = await db.query(
    "INSERT INTO Manager (name, email, idGoogle) VALUES (?, ?, ?)",
    [name, email, idGoogle]
  );

  return { id: (result as any).insertId };
}
