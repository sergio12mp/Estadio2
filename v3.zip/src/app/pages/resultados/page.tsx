import { FooterHome } from "@/components/footer";

export default function Resultados() {
    return (


        <div> <h1>Resultados</h1>

            <footer>
                <FooterHome />
            </footer></div>

    );
}