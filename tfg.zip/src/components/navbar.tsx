// src/components/NavBar.tsx

"use client";

import Link from "next/link";
import SignInButton from "./SignInButton";
import SignOutButton from "./SignOutButton";

interface Props {
  session: any;
}

export default function NavBar({ session }: Props) {
  return (
    <nav className="bg-blue-600 text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/" className="text-xl font-bold">
          Mi Aplicación
        </Link>

        <div className="flex items-center space-x-4">
          <Link href="/about" className="hover:underline">
            Sobre nosotros
          </Link>

          {session ? (
            <>
              <Link href="/dashboard" className="hover:underline">
                Dashboard
              </Link>
              <Link href ="/miequipo" className="hover:underline">
                Mi Equipo
              </Link>
              <Link href="/profile" className="hover:underline">
                Perfil
              </Link>
              <SignOutButton />
            </>
          ) : (
            <SignInButton />
          )}
        </div>
      </div>
    </nav>
  );
}
