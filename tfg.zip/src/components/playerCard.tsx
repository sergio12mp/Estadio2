import React from 'react';
import { Jugador, Equipo } from '@/lib/data';

interface PlayerCardProps {
  jugador: Jugador;
  equipos: Equipo[];
}

const PlayerCard: React.FC<PlayerCardProps> = ({ jugador, equipos }) => {
  return (
    <div key={jugador.idJugador} style={{ padding: '10px', border: '1px solid #ddd', marginBottom: '10px' }}>
      <h3>{jugador.Nombre}</h3>
      <p>Edad: {jugador.Edad}</p>
      <p>País: {jugador.Pais}</p>
      <p>Posición: {jugador.Posicion}</p>
      <p>Precio: {jugador.Precio}</p>
      <p>Puntos: {}</p>
      <p>Rareza: </p>
      <p>Equipo: {equipos.find((equipo) => equipo.idEquipo === jugador.idEquipo)?.Nombre ?? 'Agente Libre'}</p>
    </div>
  );
};

export default PlayerCard;
