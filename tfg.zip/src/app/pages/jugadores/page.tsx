"use client";
import React, { useState, useEffect } from 'react';
import { Equipo, Jugador } from '@/lib/data';
import { FooterHome } from '@/components/footer';
import PlayerSelection from '@/components/playerSelection';
import PlayerCard from '@/components/playerCard';

const Jugadores: React.FC = () => {
    let playerIndex = 1;
    const [query, setQuery] = useState('');
    const [jugadores, setJugadores] = useState<Jugador[]>([]);
    const [equipos, setEquipos] = useState<Equipo[]>([]);
    //const [filteredJugadores, setJugadoresEquipo] = useState<Jugador[]>([]);

    useEffect(() => {
        const fetchJugadores = async () => {
            try {
                const responseEquipo = await fetch('/api/equipo');
               const dataEquipo = await responseEquipo.json();
                const responseJugador = await fetch('/api/jugador');
                const dataJugador = await responseJugador.json();

                setJugadores(dataJugador.result); // Extrae el array `result` de la respuesta
                setEquipos(dataEquipo);

             

            } catch (error) {
                console.error('Error fetching players:', error);
            }
        };
    
        fetchJugadores();
    }, []);
    
    

    

    /*
        useEffect(() => {
            setFilteredJugadores(
                jugadores.filter((jugador) =>
                    jugador.Nombre.toLowerCase().includes(query.toLowerCase())
                )
            );
        }, [query, jugadores]);*/

    return (
        <div>
            <input
                type="text"
                placeholder="Buscar jugadores..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                style={{ padding: '10px', marginBottom: '20px', width: '100%' }}
            />
            <div>
               {/* {filteredJugadores.length > 0 ? (
                    filteredJugadores.map((jugador) => (
                        <div key={jugador.idJugador} style={{ padding: '10px', border: '1px solid #ddd', marginBottom: '10px' }}>
                            <h3>{jugador.Nombre}</h3>
                            <p>Edad: {jugador.Edad}</p>
                            <p>País: {jugador.Pais}</p>
                            <p>Posición: {jugador.Posicion}</p>
                            <p>Precio: {jugador.Precio}</p>
                            <p>Equipo: {jugador.idEquipo}</p>
                        </div>
                    ))
                ) : (
                    <p>No se encontraron jugadores</p>
                )} */}
            </div>
            <div>

            {jugadores.map((jugador) => (
          <PlayerCard key={jugador.idJugador} jugador={jugador} equipos={equipos} />
        ))}
            </div>
            <div>
            <PlayerSelection
                    key={playerIndex}
                    idJugador={playerIndex}
                    Nombre={`Jugador ${playerIndex}`}
                    idEquipo={playerIndex}
                    Posicion={''}
                    Precio={playerIndex * 10}
                    Edad={''}
                    Pais={''} 
                     />
            </div>
            <footer>
                <FooterHome />
            </footer>
        </div>
    );
};

export default Jugadores;
