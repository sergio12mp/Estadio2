import { getSession, signOut } from 'next-auth/react';
import { GetServerSideProps } from 'next';
import { Manager } from '@/lib/data';

export default function MiEquipo(user :Manager) {
  return (
    <div className="text-center mt-10">
      <h1>Welcome to Mi Equipo, {user?.name}</h1>
      <button
        onClick={() => signOut()}
        className="mt-4 px-4 py-2 bg-red-500 text-white rounded"
      >
        Sign Out
      </button>
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  const session = await getSession(context);

  if (!session) {
    return {
      redirect: {
        destination: '/auth/signin',
        permanent: false,
      },
    };
  }

  return {
    props: { user: session.user },
  };
};