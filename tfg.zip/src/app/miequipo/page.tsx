// src/app/miequipo/page.tsx

import { getServerSession } from "next-auth";
import { authOptions } from "../api/auth/[...nextauth]/route";

export default async function MiEquipoPage() {
  const session = await getServerSession(authOptions);

  if (!session) {
    // Si no hay sesión, redirige o muestra un mensaje
    return (
      <div>
        <p>No tienes permiso para ver esta página. Por favor, inicia sesión.</p>
      </div>
    );
  }

  return (
    <div>
      <h1>Bienvenido al equipo, {session.user?.name}!</h1>
      <p>Correo electrónico: {session.user?.email}</p>
    </div>
  );
}
