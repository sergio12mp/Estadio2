// src/app/layout.tsx

import "./globals.css";
import NavBarWrapper from "@/components/NavBarWrapper";
import SessionProviderWrapper from "@/components/SessionProviderWrapper";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body>
        <SessionProviderWrapper>
          <NavBarWrapper />
          {children}
        </SessionProviderWrapper>
      </body>
    </html>
  );
}
