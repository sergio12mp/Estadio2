"use client";

import RequireAdmin from "@/components/RequireAdmin";
import SeleccionarJornada from "@/components/SeleccionarJornada";
import { useEffect, useState } from "react";

export default function DashboardPage() {
  const [fechaActual, setFechaActual] = useState("");
  const [nuevaFecha, setNuevaFecha] = useState("");
  const [guardando, setGuardando] = useState(false);
  const [mensaje, setMensaje] = useState("");

  useEffect(() => {
    const cargar = async () => {
      const res = await fetch("/api/simulated-time");
      const data = await res.json();
      const fechaIso = new Date(data.fecha).toISOString().slice(0, 16);
      setFechaActual(fechaIso);
      setNuevaFecha(fechaIso);
    };

    cargar();
  }, []);

  const guardarFecha = async () => {
    setGuardando(true);
    setMensaje("");

    try {
      const res = await fetch("/api/simulated-time", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fecha: nuevaFecha }),
      });

      if (res.ok) {
        setMensaje("Fecha actualizada correctamente.");
        setFechaActual(nuevaFecha);
      } else {
        const data = await res.json();
        setMensaje(data.error || "Error al actualizar.");
      }
    } catch (err) {
      setMensaje("Error de red.");
    } finally {
      setGuardando(false);
    }
  };

  return (
    <RequireAdmin>
      <div className="max-w-2xl mx-auto mt-10 px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-8 text-center">Panel de Administración</h1>

        <div className="bg-white shadow-lg rounded-lg p-6 border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">🕒 Control de Tiempo Simulado</h2>

          <label className="block text-gray-800 font-medium mb-2">
            Fecha actual simulada:
          </label>

          <input
            type="datetime-local"
            value={nuevaFecha}
            onChange={(e) => setNuevaFecha(e.target.value)}
            className="w-full px-3 py-2 border border-gray-400 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
          />

          <button
            onClick={guardarFecha}
            disabled={guardando}
            className="bg-blue-600 text-white font-medium py-2 px-4 rounded-md hover:bg-blue-700 disabled:opacity-50 transition"
          >
            {guardando ? "Guardando..." : "Guardar"}
          </button>

          {mensaje && <p className="mt-3 text-sm text-gray-800">{mensaje}</p>}
        </div>
        <div className="mt-10 bg-white p-6 rounded shadow-md border">
          <h2 className="text-xl font-semibold mb-4">📊 Obtener estadísticas por jornada</h2>

          <div className="flex gap-4 mb-4">
            <input
              type="number"
              placeholder="Número de jornada"
              className="border px-3 py-2 rounded w-40"
            />

            <SeleccionarJornada />
            
          </div>

          <p className="text-red-600 text-sm"></p>
        </div>
      </div>
    </RequireAdmin>
  );
}
