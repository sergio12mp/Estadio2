import { db } from "@/lib/mysql";
import { NextRequest, NextResponse } from "next/server";


export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const idGoogle = searchParams.get("idGoogle");

    if (!idGoogle) {
      return NextResponse.json({ error: "Falta el parámetro idGoogle" }, { status: 400 });
    }

    const result = await db.query("SELECT * FROM Manager WHERE idGoogle = ?", [idGoogle]);
    const manager = (result as any)[0]; // ✅ directamente el objeto

    console.log("✅ Manager encontrado:", manager);

    if (!manager) {
      return NextResponse.json({ found: false }, { status: 404 });
    }

    return NextResponse.json({ found: true, manager });
  } catch (error: any) {
    console.error("❌ Error en GET /api/manager:", error.message);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

  export async function POST(req: NextRequest) {
    try {
      const { name, email, idGoogle } = await req.json();
  
      if (!name || !email || !idGoogle) {
        return NextResponse.json({ error: "Faltan campos requeridos" }, { status: 400 });
      }
  
      const [existingRows]: [any[]] = await db.query(
        "SELECT * FROM Manager WHERE idGoogle = ?",
        [idGoogle]
      );
  
      if (existingRows && existingRows.length > 0) {
        return NextResponse.json({ created: false, id: existingRows[0].idManager });
      }
  
      const [result]: [any] = await db.query(
        "INSERT INTO Manager (nombre, email, idGoogle) VALUES (?, ?, ?)",
        [name, email, idGoogle]
      );
  
      return NextResponse.json({
        created: true,
        id: result.insertId,
      });
    } catch (error: any) {
      console.error("❌ Error en POST /api/manager:", error.message);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
  }
  