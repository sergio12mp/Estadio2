"use client";

import { useAuth } from "@/context/auth-context";
import { useEffect, useState } from "react";
import NavBar from "./navbar";
import { NavbarLite } from "./navbarLite";

export function SelectNavbar() {
  const { user } = useAuth();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const syncManager = async () => {
      if (!user?.uid || !user.displayName || !user.email) {
        setReady(true);
        return;
      }

      try {
        // Buscar por idGoogle
        const res = await fetch(`/api/manager?idGoogle=${user.uid}`);

        if (res.status === 404) {
          // Crear si no existe
          await fetch("/api/manager", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              name: user.displayName,
              email: user.email,
              idGoogle: user.uid,
            }),
          });
        }
      } catch (err) {
        console.error("❌ Error sincronizando manager:", err);
      } finally {
        setReady(true);
      }
    };

    syncManager();
  }, [user]);

  if (!ready) return <p>Cargando...</p>;

  return user ? <NavBar /> : <NavbarLite />;
}
