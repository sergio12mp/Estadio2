"use client";

import Link from "next/link";
import { useAuth } from "@/context/auth-context";
import SignOutButton from "./SignOutButton";
import LoginButton from "./LoginButton";

export default function NavBar() {
  const { user } = useAuth();

  return (
    <nav className="bg-blue-600 text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/" className="text-xl font-bold">
          Mi Aplicación
        </Link>

        <div className="flex items-center space-x-4">
          <Link href="/about" className="hover:underline">
            Sobre nosotros
          </Link>

          {user ? (
            <>
            <Link href="/mi-perfil" className="hover:underline">Mi Perfil</Link>

              <Link href="/dashboard" className="hover:underline">
                Dashboard
              </Link>
              <Link href="/miequipo" className="hover:underline">
                Mi Equipo
              </Link>
              <Link href="/profile" className="hover:underline">
                Perfil
              </Link>
              <SignOutButton />
            </>
          ) : (
            <LoginButton />
          )}
        </div>
      </div>
    </nav>
  );
}
